# 十月，見字如面

一封生日書信，附可修改的邀約回覆表單。

預定公開網址：https://vansonlin81.github.io/small-project/

## 開發與發布

使用 Node.js 22.12 以上版本。

```sh
npm ci
npm run dev
npm run build
```

`src/` 是 React 原始碼，`docs/` 是 GitHub Pages 的靜態發布檔案。修改後執行 `npm run build`，把原始碼及 `docs/` 一起提交。

GitHub repository 的 Settings → Pages 設定 Deploy from a branch，分支 `main`、目錄 `/docs`。

## 回覆資料與通知

GitHub Pages 提供信件畫面；回覆仍由原本網站的 `/api/reply` 儲存到資料庫，因此兩個網址共用同一份回覆，可重新查看或修改。後端位於 https://october-letter-for-you.v0900173978.chatgpt.site/ ，需要持續運作。

`backend/` 保存對應的後端程式參考與資料表 migration；它不會在 GitHub Pages 上執行。這個 repository 不包含資料庫內容、憑證或環境變數。現有 Gmail 通知由已設定的自動化處理；不由 GitHub Pages 或瀏覽器寄信。舊 FormSubmit 寄信方式保持停用。

公開網址的訪客共用一份邀約回覆。請勿把機密內容寫入表單。

## 字型

使用 LXGW WenKai TC 與 Noto Serif TC 的字型子集，授權文字見 `public/licenses/`。
