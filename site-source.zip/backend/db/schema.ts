import { sqliteTable,text } from 'drizzle-orm/sqlite-core';
export const replies=sqliteTable('replies',{id:text('id').primaryKey(),response:text('response').notNull(),slots:text('slots').notNull(),place:text('place').notNull(),message:text('message').notNull(),updatedAt:text('updated_at').notNull(),emailStatus:text('email_status').notNull().default('disabled')});
