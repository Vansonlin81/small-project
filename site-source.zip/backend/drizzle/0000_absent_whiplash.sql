CREATE TABLE `replies` (
	`id` text PRIMARY KEY NOT NULL,
	`response` text NOT NULL,
	`slots` text NOT NULL,
	`place` text NOT NULL,
	`message` text NOT NULL,
	`updated_at` text NOT NULL
);
