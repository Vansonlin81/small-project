import type { Reply } from './reply';
import { sendReplyEmail, type EmailConfig } from './reply-email';
export const READ_REPLY_SQL = 'SELECT response, slots, place, message, updated_at AS updatedAt, email_status AS emailStatus FROM replies WHERE id = ?';
export const SAVE_REPLY_SQL = `INSERT INTO replies (id,response,slots,place,message,updated_at,email_status,email_message_id) VALUES (?,?,?,?,?,?,?,NULL)
 ON CONFLICT(id) DO UPDATE SET response=excluded.response,slots=excluded.slots,place=excluded.place,message=excluded.message,updated_at=excluded.updated_at,email_status=excluded.email_status,email_message_id=NULL
 WHERE replies.response != excluded.response OR replies.slots != excluded.slots OR replies.place != excluded.place OR replies.message != excluded.message OR (replies.email_status = 'disabled' AND ? = 1)
 RETURNING response, slots, place, message, updated_at AS updatedAt, email_status AS emailStatus`;
export type ReplyRow = { response: Reply['response']; slots: string; place: string; message: string; updatedAt: string; emailStatus: string };
export function unpackReply(row: ReplyRow): Reply & { updatedAt: string } { return { ...row, slots: JSON.parse(row.slots) }; }
export async function submitReply(db: D1Database, reply: Reply, config: EmailConfig, transport: typeof fetch = fetch) {
 // The conditional upsert is atomic: unchanged and concurrent duplicate submits do not send again.
 const row = await db.prepare(SAVE_REPLY_SQL).bind('october-2026', reply.response, JSON.stringify(reply.slots), reply.place, reply.message, new Date().toISOString(), 'pending', config.apiKey && config.from ? 1 : 0).first<ReplyRow>();
 if (!row) {
  const existing = await db.prepare(READ_REPLY_SQL).bind('october-2026').first<ReplyRow>();
  if (!existing) throw new Error('Saved reply unavailable');
  return unpackReply(existing);
 }
 const saved = unpackReply(row);
 // Sending starts only after successful durable storage; no GET, rendering or build can send email.
 const delivery = await sendReplyEmail(saved, config, transport);
 try {
  await db.prepare('UPDATE replies SET email_status = ?, email_message_id = ? WHERE id = ? AND updated_at = ?').bind(delivery.status, delivery.messageId ?? null, 'october-2026', saved.updatedAt).run();
 } catch {
  // Do not send again if recording the provider receipt failed.
  console.error('Reply delivery receipt could not be saved');
 }
 return { ...saved, emailStatus: delivery.status };
}
