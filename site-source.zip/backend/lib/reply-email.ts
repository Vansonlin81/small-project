import type { Reply } from './reply';
export type EmailStatus='disabled'|'accepted'|'activation_required'|'failed'|'unknown';
export const LETTER_URL='https://october-letter-for-you.v0900173978.chatgpt.site/';
export function emailPayload(reply:Reply){
 return {_subject:'【生日邀約】收到一封回信了',_template:'table',_captcha:'false',_url:LETTER_URL,
 '回覆':reply.response==='yes'?'准許攜糕出席':'時間再一起商量',
 '方便的時間':reply.slots.length?reply.slots.map(s=>`${s.date} ${s.times.join('、')}`).join('\n'):'時間再一起商量',
 '見面地點':reply.place||'我們再一起決定','留言':reply.message||'未留言',
 '回覆時間':reply.updatedAt?new Date(reply.updatedAt).toLocaleString('zh-TW',{timeZone:'Asia/Taipei',hour12:false}):'未指定',
 '查看信件':LETTER_URL};
}
export async function sendReplyEmail(reply:Reply,config:{enabled?:string;recipient?:string},transport:typeof fetch=fetch):Promise<EmailStatus>{
 // This guard remains off until the owner approves this delivery provider.
 if(config.enabled!=='true'||!config.recipient)return 'disabled';
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(config.recipient))return 'failed';
 try{
  const response=await transport(`https://formsubmit.co/ajax/${encodeURIComponent(config.recipient)}`,{method:'POST',headers:{'Content-Type':'application/json','Accept':'application/json'},body:JSON.stringify(emailPayload(reply)),signal:AbortSignal.timeout(15000)});
  if(!response.ok)return response.status>=500?'unknown':'failed';
  const data=await response.json() as {success?:boolean|string;message?:string};
  if(/activat|confirm your (form|email)/i.test(data.message??''))return 'activation_required';
  return data.success===true||data.success==='true'?'accepted':'failed';
 }catch{return 'unknown'}
}
