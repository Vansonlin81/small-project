import type { Reply } from './reply';
export type EmailStatus = 'disabled' | 'accepted' | 'failed' | 'unknown' | 'skipped';
export type EmailDelivery = { status: EmailStatus; messageId?: string };
export type EmailConfig = { apiKey?: string; from?: string };
export const EMAIL_RECIPIENT = 'v0900173978@gmail.com';
export const LETTER_URL = 'https://vansonlin81.github.io/small-project/';
export function replyNumber(updatedAt: string) { return 'octoberreply6abd0493' + updatedAt.replace(/\D/g, ''); }
export function isTestReply(reply: Reply) { return /【(?:測試|TEST)】/i.test(JSON.stringify(reply)); }
export function emailText(reply: Reply & { updatedAt: string }) {
 const slots = reply.slots.length ? reply.slots.map(s => `${s.date} ${s.times.join('、')}`).join('\n') : '時間再一起商量';
 return [
  '【生日邀約回覆】',
  `回覆意願：${reply.response === 'yes' ? '准許攜糕出席' : '時間再一起商量'}`,
  `日期與時段：\n${slots}`,
  `地點：${reply.place.trim() ? reply.place : '待商量'}`,
  `留言：\n${reply.message.trim() ? reply.message : '未留言'}`,
  `提交時間：${new Intl.DateTimeFormat('zh-TW', { timeZone: 'Asia/Taipei', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }).format(new Date(reply.updatedAt))}（Asia/Taipei）`,
  `查看信件：${LETTER_URL}`,
  `回覆編號：${replyNumber(reply.updatedAt)}`,
 ].join('\n\n');
}
export async function sendReplyEmail(reply: Reply & { updatedAt: string }, config: EmailConfig, transport: typeof fetch = fetch): Promise<EmailDelivery> {
 if (isTestReply(reply)) return { status: 'skipped' };
 // Missing credentials never turn a saved reply into a false delivery success.
 if (!config.apiKey || !config.from) return { status: 'disabled' };
 // Production requires an owner-configured sender, never the test domain.
 if (/[\r\n]/.test(config.from) || !/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(config.from) || config.from.toLowerCase().endsWith('@resend.dev')) return { status: 'failed' };
 try {
  const payload = { from: `十月，見字如面 <${config.from}>`, to: [EMAIL_RECIPIENT], subject: '【生日邀約回覆】收到填寫結果', text: emailText(reply) };
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(JSON.stringify(payload)));
  const fingerprint = Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, '0')).join('').slice(0, 16);
  const response = await transport('https://api.resend.com/emails', {
   method: 'POST', headers: { Authorization: `Bearer ${config.apiKey}`, 'Content-Type': 'application/json', 'Idempotency-Key': replyNumber(reply.updatedAt) + '-' + fingerprint },
   body: JSON.stringify(payload),
   signal: AbortSignal.timeout(15000),
  });
  if (!response.ok) return { status: response.status >= 500 || response.status === 409 ? 'unknown' : 'failed' };
  const data = await response.json() as { id?: unknown };
  return typeof data.id === 'string' && data.id.length > 0 && data.id.length < 200 ? { status: 'accepted', messageId: data.id } : { status: 'unknown' };
 } catch { return { status: 'unknown' }; }
}
