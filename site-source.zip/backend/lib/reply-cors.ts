const GITHUB_PAGES_ORIGIN = 'https://vansonlin81.github.io';
export function replyOriginAllowed(request: Request): boolean {
  const origin = request.headers.get('origin');
  return origin === new URL(request.url).origin || origin === GITHUB_PAGES_ORIGIN;
}
export function replyHeaders(request: Request): Record<string, string> {
  const headers: Record<string, string> = {'Cache-Control': 'no-store', Vary: 'Origin'};
  if (replyOriginAllowed(request)) {
    headers['Access-Control-Allow-Origin'] = request.headers.get('origin')!;
    headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS';
    headers['Access-Control-Allow-Headers'] = 'Content-Type';
    headers['Access-Control-Max-Age'] = '600';
  }
  return headers;
}
