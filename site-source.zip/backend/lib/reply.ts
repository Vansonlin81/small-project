export const PERIODS=['中午','下午','晚上'] as const;
export const FIXED_SLOTS=[{date:'2026-10-09',time:'中午'},{date:'2026-10-09',time:'晚上'},{date:'2026-10-10',time:'中午'}] as const;
export const OTHER_WEEKENDS=Array.from({length:31},(_,i)=>`2026-10-${String(i+1).padStart(2,'0')}`).filter(date=>date!=='2026-10-10'&&[0,6].includes(new Date(date+'T12:00:00Z').getUTCDay()));
export function availablePeriods(date:string):readonly string[]{if(date==='2026-10-09')return ['中午','晚上'];if(date==='2026-10-10')return ['中午'];return OTHER_WEEKENDS.includes(date)?PERIODS:[];}
export type Reply={response:'yes'|'later';slots:{date:string;times:string[]}[];place:string;message:string;updatedAt?:string;emailStatus?:string};
export function validateReply(value:unknown):Reply{
 if(!value||typeof value!=='object')throw new Error('請確認回信內容。');
 const v=value as Reply;
 if(!['yes','later'].includes(v.response)||!Array.isArray(v.slots)||v.slots.length>31||typeof v.place!=='string'||typeof v.message!=='string'||v.place.length>200||v.message.length>2000)throw new Error('請確認回信內容與字數。');
 const slots=v.slots.map(s=>{if(!s||typeof s.date!=='string'||!/^2026-10-(0[1-9]|[12]\d|3[01])$/.test(s.date)||!Array.isArray(s.times)||s.times.length===0||s.times.length>3||s.times.some(t=>!availablePeriods(s.date).includes(t)))throw new Error('請選擇 10/9 中午或晚上、10/10 中午，或十月其餘週末。');return {date:s.date,times:[...new Set(s.times)]};});
 if(v.response==='yes'&&!slots.length)throw new Error('請至少選一天，或選擇「時間再一起商量」。');
 return {response:v.response,slots:v.response==='later'?[]:slots.sort((a,b)=>a.date.localeCompare(b.date)),place:v.place.trim(),message:v.message};
}
