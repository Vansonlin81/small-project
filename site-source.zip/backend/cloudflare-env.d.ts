declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    RESEND_API_KEY?: string;
    EMAIL_FROM?: string;
    EMAIL_DELIVERY_ENABLED?: string;
    EMAIL_RECIPIENT?: string;
    BUCKET?: R2Bucket;
  }
}
