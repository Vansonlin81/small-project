declare namespace Cloudflare {
  interface Env {
    DB?: D1Database;
    EMAIL_DELIVERY_ENABLED?: string;
    EMAIL_RECIPIENT?: string;
    BUCKET?: R2Bucket;
  }
}
