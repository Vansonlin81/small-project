import { replyOriginAllowed, replyHeaders } from '@/lib/reply-cors';
import { env } from 'cloudflare:workers';
import { sendReplyEmail } from '@/lib/reply-email';
import { getDatabase } from '@/db';
import { validateReply } from '@/lib/reply';
export const dynamic='force-dynamic';

export async function GET(request:Request){const headers=replyHeaders(request);try{const row=await getDatabase().prepare('SELECT response, slots, place, message, updated_at AS updatedAt, email_status AS emailStatus FROM replies WHERE id = ?').bind('october-2026').first();return Response.json({reply:row?{...row,slots:JSON.parse(row.slots as string)}:null},{headers});}catch(error){console.error('Reply read failed',error);return Response.json({error:'暫時讀不到回信，請稍後再試。'},{status:503,headers});}}
export async function POST(request:Request){
 const headers=replyHeaders(request);
 if(!replyOriginAllowed(request))return Response.json({error:'請從信件頁面寄出回信。'},{status:403,headers});
 const raw=await request.text();if(raw.length>12000)return Response.json({error:'回信太長了，請縮短一些。'},{status:413,headers});
 let reply;try{reply=validateReply(JSON.parse(raw));}catch(error){return Response.json({error:error instanceof Error?error.message:'回信格式不正確。'},{status:400,headers});}
 try{const updatedAt=new Date().toISOString();await getDatabase().prepare('INSERT INTO replies (id,response,slots,place,message,updated_at,email_status) VALUES (?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET response=excluded.response,slots=excluded.slots,place=excluded.place,message=excluded.message,updated_at=excluded.updated_at,email_status=excluded.email_status').bind('october-2026',reply.response,JSON.stringify(reply.slots),reply.place,reply.message,updatedAt,'pending').run();
 const emailStatus=await sendReplyEmail({...reply,updatedAt},{enabled:env.EMAIL_DELIVERY_ENABLED,recipient:env.EMAIL_RECIPIENT});
 try{await getDatabase().prepare('UPDATE replies SET email_status = ? WHERE id = ? AND updated_at = ?').bind(emailStatus,'october-2026',updatedAt).run()}catch(error){console.error('Email status save failed',error)}
 return Response.json({reply:{...reply,updatedAt,emailStatus}},{headers});}catch(error){console.error('Reply save failed',error);return Response.json({error:'信還沒寄出，內容已保留在畫面上，請再試一次。'},{status:503,headers});}
}

export async function OPTIONS(request:Request){return new Response(null,{status:replyOriginAllowed(request)?204:403,headers:replyHeaders(request)});}
