import { replyOriginAllowed, replyHeaders } from '@/lib/reply-cors';
import { env } from 'cloudflare:workers';
import { submitReply } from '@/lib/reply-submission';
import { getDatabase } from '@/db';
import { validateReply } from '@/lib/reply';
export const dynamic='force-dynamic';

export async function GET(request:Request){const headers=replyHeaders(request);try{const row=await getDatabase().prepare('SELECT response, slots, place, message, updated_at AS updatedAt, email_status AS emailStatus FROM replies WHERE id = ?').bind('october-2026').first();return Response.json({reply:row?{...row,slots:JSON.parse(row.slots as string)}:null},{headers});}catch(error){console.error('Reply read failed',error);return Response.json({error:'暫時讀不到回信，請稍後再試。'},{status:503,headers});}}
export async function POST(request:Request){
 const headers=replyHeaders(request);
 if(!replyOriginAllowed(request))return Response.json({error:'請從信件頁面寄出回信。'},{status:403,headers});
 const raw=await request.text();if(raw.length>12000)return Response.json({error:'回信太長了，請縮短一些。'},{status:413,headers});
 let reply;try{reply=validateReply(JSON.parse(raw));}catch(error){return Response.json({error:error instanceof Error?error.message:'回信格式不正確。'},{status:400,headers});}
 try{const saved=await submitReply(getDatabase(),reply,{apiKey:env.RESEND_API_KEY,from:env.EMAIL_FROM});
 return Response.json({reply:saved},{headers});}catch(error){console.error('Reply save failed',error);return Response.json({error:'回信尚未保存，內容已保留在畫面上，請再試一次。'},{status:503,headers});}
}

export async function OPTIONS(request:Request){return new Response(null,{status:replyOriginAllowed(request)?204:403,headers:replyHeaders(request)});}
